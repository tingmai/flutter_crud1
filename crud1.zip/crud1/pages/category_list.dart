
import 'package:flutter/material.dart';
import 'package:flutter_application_1/crud1/pages/category_create.dart';
import 'package:flutter_application_1/crud1/pages/category_edit.dart';

import '../models/category.dart';
import '../repositories/category_repository.dart';
import '../widgets/category_card.dart';


class CategoryListPage extends StatefulWidget {
  const CategoryListPage({super.key});

  @override
  State<CategoryListPage> createState() =>
      _CategoryListPageState();
}

class _CategoryListPageState
    extends State<CategoryListPage> {

  final repository = CategoryRepository();

  List<Category> categories = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadCategories();
  }

  // READ
  Future<void> loadCategories() async {
    setState(() {
      isLoading = true;
    });

    try {
      final data = await repository.getAll();

      if (!mounted) return;

      setState(() {
        categories = data;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  // CREATE PAGE
  Future<void> openCreatePage() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const CategoryCreatePage(),
      ),
    );

    if (result == true) {
      loadCategories();
    }
  }

  // EDIT PAGE
  Future<void> openEditPage(Category category) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CategoryEditPage(
          category: category,
        ),
      ),
    );

    if (result == true) {
      loadCategories();
    }
  }

  // DELETE
  Future<void> deleteCategory(int id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Category'),
        content: const Text(
          'Are you sure you want to delete this category?',
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () =>
                Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    await repository.delete(id);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Category Deleted Successfully'),
      ),
    );

    loadCategories();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Category Management'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            onPressed: loadCategories,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),

      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : categories.isEmpty
              ? const Center(
                  child: Text('No Categories Found'),
                )
              : RefreshIndicator(
                  onRefresh: loadCategories,
                  child: ListView.builder(
                    itemCount: categories.length,
                    itemBuilder: (context, index) {
                      final category = categories[index];

                      return CategoryCard(
                        category: category,
                        onEdit: () =>
                            openEditPage(category),
                        onDelete: () =>
                            deleteCategory(category.id!),
                      );
                    },
                  ),
                ),

      floatingActionButton: FloatingActionButton(
        onPressed: openCreatePage,
        child: const Icon(Icons.add),
      ),
    );
  }
}
