
import 'package:flutter/material.dart';
import '../models/category.dart';
import '../repositories/category_repository.dart';

class CategoryEditPage extends StatefulWidget {
  final Category category;

  const CategoryEditPage({
    super.key,
    required this.category,
  });

  @override
  State<CategoryEditPage> createState() =>
      _CategoryEditPageState();
}

class _CategoryEditPageState
    extends State<CategoryEditPage> {

  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();

  final repository = CategoryRepository();

  @override
  void initState() {
    super.initState();

    _nameController.text = widget.category.name;
  }

  Future<void> updateCategory() async {
    if (!_formKey.currentState!.validate()) return;

    final category = Category(
      id: widget.category.id,
      name: _nameController.text.trim(),
    );

    await repository.update(category);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Category Updated Successfully'),
      ),
    );

    Navigator.pop(context, true);
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Category'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Category Name',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.category),
                ),
                validator: (value) {
                  if (value == null ||
                      value.trim().isEmpty) {
                    return 'Please enter category name';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: updateCategory,
                  icon: const Icon(Icons.update),
                  label: const Text('Update Category'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
