
import 'package:flutter/material.dart';
import '../models/category.dart';
import '../repositories/category_repository.dart';

class CategoryCreatePage extends StatefulWidget {
  const CategoryCreatePage({super.key});

  @override
  State<CategoryCreatePage> createState() =>
      _CategoryCreatePageState();
}

class _CategoryCreatePageState
    extends State<CategoryCreatePage> {

  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();

  final repository = CategoryRepository();

  Future<void> saveCategory() async {
    if (!_formKey.currentState!.validate()) return;

    final category = Category(
      name: _nameController.text.trim(),
    );

    await repository.create(category);

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Category Created Successfully'),
      ),
    );

    Navigator.pop(context, true);
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Category'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Category Name',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.category),
                ),
                validator: (value) {
                  if (value == null ||
                      value.trim().isEmpty) {
                    return 'Please enter category name';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: saveCategory,
                  icon: const Icon(Icons.save),
                  label: const Text('Save Category'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
