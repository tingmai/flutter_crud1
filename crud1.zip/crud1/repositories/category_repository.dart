

import 'package:flutter_application_1/crud1/database/database_helper.dart';
import 'package:flutter_application_1/crud1/models/category.dart';

class CategoryRepository {
  final dbHelper=DatabaseHelper.instance;

  // ==========================================
  // CRUD Operations (Create, Read, Update, Delete)
  // ==========================================

  // CREATE: Insert a row into the database
  Future<int> create(Category category) async {
    final db=await dbHelper.database;
    return await db.insert('categories', category.toMap());
  }

  // READ ALL: Get all rows from the table
  Future<List<Category>> getAll() async {
    final db = await dbHelper.database;
    final result=await db.query('categories',orderBy: 'id DESC');
    return result.map((map)=>Category.fromMap(map)).toList();
  }

  // UPDATE: Modify an existing row based on its ID
  Future<int> update(Category category) async {
    final db = await dbHelper.database;

    
    return await db.update(
      'categories',
      category.toMap(),
      where: 'id = ?',
      whereArgs: [category.id],
    );
  }

  // DELETE: Remove a row based on its ID
  Future<int> delete(int id) async {
    final db = await dbHelper.database;
    return await db.delete(
      'categories',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}